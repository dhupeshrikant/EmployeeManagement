var addEmployee = function(e, id) {
	e.preventDefault();
	if (!!id) {
		url = "http://localhost:8086/employee/";
		type = "PUT";
		var formObject = {
			id : id
		};
	} else {
		url = "http://localhost:8086/employee/";
		type = "POST";
		var formObject = {};
	}
	var formData = new FormData(document.getElementById("employeeForm"));
	formData.forEach(function(value, key) {
		formObject[key] = value;
	});
	formObject = JSON.stringify(formObject);
	$.ajax({
		type : type,
		url : url,
		data : formObject,
		success : function(data, status) {
			alert(data, status);
			$('form#employeeForm')[0].reset();
			window.location.href = 'index.html';
		},
		datatype : "application/json",
		contentType : "application/json"
	});
}



shows = function(data) {
	$('#employeeTable').dataTable({
		"bDestroy" : true,
		"paging" : false,
		"aaData" : data,
		"sPaginationType": "listbox",
		"aoColumns" : [ {
			data : "fullName",
			'title' : " Name"
		}, {
			data : "email",
			'title' : "Username"
		}, {
			data : "salary",
			'title' : "Salary"
		}, {
			data : "status",
			'title' : "Status"
		}, {
			data : "id",
			'title' : "Operation"
		} ],
		'columnDefs' : [ {
			'targets' : 4,
			'className' : 'dt-body-center',
			'render' : function(data, type,
					full, meta) {
				if (full.status == "ACTIVE") {
					var status = '<button value="'
							+ $('<div/>').text(
									data)
									.html()
							+ '" onclick="deleteRow(this.value)" class="btn btn-info btn-sm"  title="Change Status">Change Status</button>'
				} else {
					var status = '<button value="'
							+ $('<div/>').text(
									data)
									.html()
							+ '" onclick="deleteRow(this.value)" class="btn btn-danger btn-sm"  title="Change Status">Change Status</button>'
				}
				return '<div class="btn-group btn-group-sm"><button type="button" value="'
						+ $('<div/>')
								.text(data)
								.html()
						+ '" onclick="edits(this.value)" class="btn btn-primary btn-sm"  title="Edit">Edit</button>'
						+ status + '</div>';
			},

		} ],
	});
}

var getData= function(){
	   var url = "http://localhost:8086/employee/";
		$.ajax({
		  type: "GET",
		  url: url,
		
		  data: null,
		  success: function(data){
         shows(data);			
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getData();
var edits = function(id){
	window.location.href=('user.html?id='+id);
}

$(document).ready(function() {
	params = getAllUrlParams(window.location.href);
	if(params){
		editEmployee(params['id']);
	}
	
});

var editEmployee = function(id) {
	$('form#employeeForm h5').text('Edit Employee');
	$('form#employeeForm').attr('onsubmit',
			'return addEmployee(event,' + id + ')');
	$.ajax({
		type : "GET",
		url : "http://localhost:8086/employee/" + id,
		success : (function(data, status) {
			data = (data);
			$.each(data, function(key, value) {
				$('form#employeeForm [name=' + key + ']').val(value);
			});
		}),
	});
}

// delete Employee
var deleteRow = function(id) {
	requesturl = "http://localhost:8086/employee/" + id, $.ajax({
		type : "DELETE",
		url : requesturl,
		data : null,
		success : function(data, status) {
			alert(data);
			window.location.reload();
		},
		datatype : "application/json",
		contentType : "application/json"
	});
}

// SEARCH
var SearchResult= function(enterNumber, opetions){
	var enterNumber = $('#enterNumber').val();
	var option = $('#opetions').val();
	var url = "http://localhost:8086/employee/search/" + enterNumber + "/"
	+ option;
	$.ajax({
		  type: "GET",
		  url: url,
		
		  data: null,
		  success: function(data){
      shows1(data);			
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};


shows1 = function(data) {
	$('#salaryTable').dataTable({
		"bDestroy" : true,
		"paging" : false,
		"aaData" : data,
		"sPaginationType": "listbox",
		"aoColumns" : [ {
			data : "fullName",
			'title' : " Name"
		}, {
			data : "email",
			'title' : "Email"
		}, {
			data : "salary",
			'title' : "Salary"
		} ],
	});
}