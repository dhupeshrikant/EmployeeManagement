package com.management.employee.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.management.employee.entity.Employee;
import com.management.employee.entity.EmployeeEntity;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	List<Employee> findBySalaryGreaterThan(double enterNumber);

	List<Employee> findBySalaryLessThan(double enterNumber);

	Page<Employee> findAll(Pageable paging);

}
