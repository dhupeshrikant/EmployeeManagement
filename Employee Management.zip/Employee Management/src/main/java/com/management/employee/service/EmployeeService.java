package com.management.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.management.employee.dao.EmployeeRepository;
import com.management.employee.dto.EmployeeDto;
import com.management.employee.entity.Employee;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

//Save And Update Employee
	@Override
	public String save(EmployeeDto employeeDto) {
		Employee employee = new Employee();
		try {
			BeanUtils.copyProperties(employeeDto, employee);
			employee.setStatus("ACTIVE");
			employeeRepository.save(employee);
			return "Saves SucessFully";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "User Not Added";
	}

//Find Employees For User
	@Override
	public List<EmployeeDto> findAll() {
		List<Employee> employee = new ArrayList<Employee>();
		employee = (List<Employee>) employeeRepository.findAll();
		List<EmployeeDto> employeeDto = new ArrayList<EmployeeDto>();
		for (Employee e : employee) {
			EmployeeDto dto = new EmployeeDto();
			BeanUtils.copyProperties(e, dto);
			employeeDto.add(dto);
		}
		return employeeDto;
	}

//Find Employe By ID
	@Override
	public EmployeeDto findById(long id) {
		Employee employee = employeeRepository.findById(id).get();
		EmployeeDto dto = new EmployeeDto();
		BeanUtils.copyProperties(employee, dto);
		return dto;
	}

//Change Employee Status
	@Override
	public String delete(long id) {
		Employee employee = new Employee();
		try {
			employee = employeeRepository.findById(id).get();
			if (employee.getStatus().equalsIgnoreCase("ACTIVE")) {
				employee.setStatus("DEACTIVE");
				employeeRepository.save(employee);
				return "Status Changed DEACTIVE";
			} else if (employee.getStatus().equalsIgnoreCase("DEACTIVE")) {
				employee.setStatus("ACTIVE");
				employeeRepository.save(employee);
				return "Status Changed ACTIVE";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Status Not Changed";
	}

//Find Salary High Or Less
	@Override
	public List<Employee> findBySalary(double enterNumber, String options) {
		List<Employee> employees = new ArrayList<Employee>();
		try {
			if (options.equalsIgnoreCase("HIGH")) {
				employees = employeeRepository.findBySalaryGreaterThan(enterNumber);
				return employees;
			} else if (options.equalsIgnoreCase("LESS")) {
				employees = employeeRepository.findBySalaryLessThan(enterNumber);
				return employees;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public String updateEmployee(Employee employee) {
		try {
			if (employee.getId() != 0) {
				employeeRepository.save(employee);
				return "Updated Success";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "Not Updated";
	}

}
