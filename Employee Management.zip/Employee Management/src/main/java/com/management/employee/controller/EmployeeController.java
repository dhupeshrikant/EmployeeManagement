package com.management.employee.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.management.employee.dao.EmployeeRepository;
import com.management.employee.dto.EmployeeDto;
import com.management.employee.entity.DataTable;
import com.management.employee.entity.Employee;
import com.management.employee.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService employeeService;
	@Autowired
	private EmployeeRepository employeeRepository;

	Logger logger = Logger.getLogger(EmployeeController.class.getName());

	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public String saveEmployee(@RequestBody EmployeeDto employeedto) {
		logger.info("New Employee Saved");
		employeeService.save(employeedto);
		logger.info("Employee Saved");

		return "saved";
	}

	@RequestMapping(value = "/employee", method = RequestMethod.PUT)
	public String updateEmployee(@RequestBody Employee employee) {
		return employeeService.updateEmployee(employee);
	}

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public List<EmployeeDto> findAllEmployee() {
		logger.info("User Find All Employees");

		return (List<EmployeeDto>) employeeService.findAll();
	}

	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET)
	public EmployeeDto findById(@PathVariable("id") long id) {
		logger.info("User Find By Id");
		return employeeService.findById(id);
	}

	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
	public String changeStatus(@PathVariable("id") long id) {
		logger.info("User Status Been Changed");
		return employeeService.delete(id);
	}

	@RequestMapping(value = "/employee/search/{salary}/{options}", method = RequestMethod.GET)
	public List<Employee> findSalary(@PathVariable("salary") double enterNumber,
			@PathVariable("options") String options) {
		logger.info("Finding Salsry On Highest Or Grator Basis");

		return employeeService.findBySalary(enterNumber, options);
	}

	// pagination
	@RequestMapping(value = "/paginations")
	public ResponseEntity listAllTable(@RequestParam("draw") int draw, @RequestParam("start") int start,
			@RequestParam("length") int length) {
		int page = start / length; // Calculate page number

		Pageable pageable = PageRequest.of(page, length
		// , new Sort(Sort.Direction.DESC, "id")
		);

		Page<Employee> responseData = employeeRepository.findAll(pageable);
		DataTable dataTable = new DataTable();
		dataTable.setData(responseData.getContent());
		dataTable.setRecordsTotal(responseData.getTotalElements());
		dataTable.setRecordsFiltered(responseData.getTotalElements());
		dataTable.setDraw(draw);
		dataTable.setStart(start);
		return ResponseEntity.ok(dataTable);

	}
}
