package com.management.employee.service;

import java.util.List;

import com.management.employee.dto.EmployeeDto;
import com.management.employee.entity.Employee;
import com.management.employee.entity.EmployeeEntity;

public interface IEmployeeService {

	public String save(EmployeeDto employeeDto);

	public List<EmployeeDto> findAll();

	public EmployeeDto findById(long id);
	
	public String delete(long id);

	public List<Employee> findBySalary(double enterNumber, String options);

	public String updateEmployee(Employee employee);


}
